/**
* @file affichage.c
*/

#include "affichage.h"


/**
 * Affiche une carte donnée.
 * @param c La carte à afficher.
 */
void afficherCarte(Carte c) {
	const char* couleurs[] = {"ROUGE", "BLEU", "JAUNE", "VERT", "NOIR"};
	const char* valeurs[] = {
		"ZERO", "UN", "DEUX", "TROIS", "QUATRE", "CINQ", "SIX", "SEPT", "HUIT", "NEUF",
		"PLUS_DEUX", "PASSE_TOUR", "CHANGEMENT_SENS", "CHANGEMENT_COULEUR"
	};

	if (!isCarteVide(c)) {
		switch (c.Couleur) {
			case ROUGE:
				setTerm(RED);
				break;
			case BLEU:
				setTerm(BLUE);
				break;
			case JAUNE:
				setTerm(YELLOW);
				break;
			case VERT:
				setTerm(GREEN);
				break;
			case NOIR:
				setTerm(BLACK);
				break;

			default:
				break;
		}

		printf("[%s, %s]\n", couleurs[c.Couleur], valeurs[c.Valeur]);
		resetTerm();
	}
	else {
		printf("Mettez ce que vous voulez.\n");
	}

}

/**
 * Affiche une carte dans l'affichage de la main du joueur actif.
 * @param c La carte à afficher.
 * @param index index de la carte dans la main du joueur
 */
void afficherCarteMain(Carte c, int index) {
	printf("%d - ", index);
	afficherCarte(c);
}

/**
 * Fonction pour afficher la main du joueur avec un choix
 * @param joueur joueur actif
 * @param carteVisible la carte actuellement au dessus de la pile de jeu de la partie
 */
void afficherMainAvecSelection(Joueur joueur, Carte carteVisible) {
	// Affichage de la carte visible
	printf("\nCarte visible : ");
	afficherCarte(carteVisible);

	// Affichage de la main du joueur
	printf("\nMain du joueur %d :\n", joueur.idJoueur);
	for (int i = 0; i < joueur.tailleMain; i++) {
		afficherCarteMain(joueur.main[i], i);
	}
	printf("%d - Piocher une carte\n", joueur.tailleMain);

}

/**
 * Affiche la main d'un joueur non actif
 * @param j joueur
 */
void afficherMain(Joueur j) {
	for (int i = 0; i < j.tailleMain; i++) {
		afficherCarte(j.main[i]);
	}
}